import React from 'react';
import { 
  Orbit, 
  LayoutDashboard, 
  Map, 
  Compass, 
  Satellite, 
  BarChart3, 
  HelpCircle, 
  Layers, 
  ExternalLink,
  Database,
  Lightbulb,
  Download,
  Radio,
  ChevronLeft,
  ChevronRight
} from 'lucide-react';
import { ScreenType } from '../../types';

interface SidebarProps {
  currentScreen: ScreenType;
  onNavigate: (screen: ScreenType) => void;
  collapsed?: boolean;
}

export const Sidebar: React.FC<SidebarProps> = ({ 
  currentScreen, 
  onNavigate,
  collapsed = false 
}) => {
  const navItems = [
    { id: 'overview', label: 'Mission Overview', badge: 'LIVE', icon: LayoutDashboard },
    { id: 'map', label: 'Light Pollution Map', badge: 'VIIRS', icon: Map },
    { id: 'locations', label: 'Dark Sky Corridors', badge: 'GPS', icon: Compass },
    { id: 'satellite', label: 'Satellite Telemetry', badge: 'ORBIT', icon: Satellite },
    { id: 'analytics', label: 'Atmospheric Analytics', icon: BarChart3 },
    { id: 'methodology', label: 'Data & Methodology', icon: Database },
    { id: 'responsible-lighting', label: 'Responsible Lighting', icon: Lightbulb },
    { id: 'how-it-works', label: 'Mission Architecture', icon: HelpCircle },
    { id: 'design-system', label: 'UI Design System', icon: Layers },
  ];

  return (
    <aside className={`h-screen sticky top-0 bg-[#050917]/95 backdrop-blur-2xl border-r border-slate-800/80 flex flex-col justify-between z-30 transition-all duration-300 shadow-[4px_0_24px_rgba(0,0,0,0.5)] ${
      collapsed ? 'w-16' : 'w-64'
    }`}>
      {/* Top Logo & Title */}
      <div>
        <div 
          onClick={() => onNavigate('landing')}
          className="h-16 flex items-center gap-3 px-4 border-b border-slate-800/80 cursor-pointer hover:bg-slate-900/40 transition-colors group relative overflow-hidden"
        >
          {/* Subtle glow highlight on logo area */}
          <div className="absolute -top-6 -left-6 w-20 h-20 bg-sky-500/10 rounded-full blur-xl pointer-events-none group-hover:bg-sky-400/20 transition-all" />

          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-sky-600 via-indigo-600 to-blue-700 p-0.5 shadow-[0_0_16px_rgba(14,165,233,0.4)] group-hover:scale-105 group-hover:shadow-[0_0_22px_rgba(56,189,248,0.6)] transition-all shrink-0">
            <div className="w-full h-full bg-[#050917] rounded-[10px] flex items-center justify-center">
              <Orbit className="w-5 h-5 text-sky-400 group-hover:rotate-45 transition-transform duration-500" />
            </div>
          </div>

          {!collapsed && (
            <div className="overflow-hidden">
              <div className="font-extrabold text-sm tracking-widest text-white font-telemetry flex items-center gap-1.5 uppercase">
                <span className="shimmer-text">AERO</span>
                <span className="text-sky-400 font-semibold">CLEAR</span>
              </div>
              <div className="text-[10px] text-slate-400 tracking-wider uppercase font-mono flex items-center gap-1.5">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_rgba(52,211,153,0.8)]" />
                <span>Orbital Telemetry</span>
              </div>
            </div>
          )}
        </div>

        {/* Navigation Section */}
        <div className="py-4 px-2.5 space-y-1">
          {!collapsed && (
            <div className="px-3 pb-2 text-[10px] font-mono uppercase tracking-widest text-slate-400 font-bold">
              Navigation Console
            </div>
          )}

          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentScreen === item.id || (item.id === 'locations' && currentScreen === 'location-details');

            return (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id as ScreenType)}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all group relative ${
                  isActive 
                    ? 'bg-gradient-to-r from-sky-950/80 via-slate-900/90 to-slate-900/60 text-white border border-sky-500/40 shadow-[0_0_20px_rgba(14,165,233,0.18)] font-semibold' 
                    : 'text-slate-400 hover:text-slate-100 hover:bg-slate-900/50 hover:border-slate-800 border border-transparent'
                }`}
                title={collapsed ? item.label : undefined}
              >
                {isActive && (
                  <span className="absolute left-0 top-1/2 -translate-y-1/2 w-1 h-6 bg-gradient-to-b from-sky-400 to-indigo-500 rounded-r shadow-[0_0_10px_rgba(56,189,248,0.8)]" />
                )}
                
                <div className="flex items-center gap-3 truncate">
                  <Icon className={`w-4 h-4 shrink-0 transition-transform duration-300 group-hover:scale-110 ${
                    isActive ? 'text-sky-400 drop-shadow-[0_0_6px_rgba(56,189,248,0.7)]' : 'text-slate-400 group-hover:text-slate-200'
                  }`} />
                  {!collapsed && (
                    <span className="truncate tracking-wide">{item.label}</span>
                  )}
                </div>

                {!collapsed && item.badge && (
                  <span className={`text-[9px] font-mono font-bold px-1.5 py-0.5 rounded tracking-wider border ${
                    isActive 
                      ? 'bg-sky-500/20 text-sky-300 border-sky-400/40' 
                      : 'bg-slate-800/80 text-slate-400 border-slate-700/60 group-hover:text-slate-300'
                  }`}>
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Footer Section */}
      <div className="p-3 border-t border-slate-800/80 space-y-2 bg-[#040714]/60">
        <a
          href="/aero-clear-project.zip"
          download="aero-clear-project.zip"
          className="w-full flex items-center justify-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold text-sky-300 hover:text-white bg-gradient-to-r from-sky-950/60 to-indigo-950/60 hover:from-sky-900/70 hover:to-indigo-900/70 border border-sky-500/30 hover:border-sky-400/50 shadow-sm transition-all group"
          title="Download complete project source ZIP"
        >
          <Download className="w-3.5 h-3.5 text-sky-400 group-hover:scale-110 transition-transform" />
          {!collapsed && <span>Export Project ZIP</span>}
        </a>

        <button
          onClick={() => onNavigate('landing')}
          className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-xs text-slate-400 hover:text-white hover:bg-slate-800/50 transition-colors"
        >
          <ExternalLink className="w-3.5 h-3.5 text-sky-400" />
          {!collapsed && <span>Landing Portal</span>}
        </button>

        {/* Operational Constellation Sync Pill */}
        {!collapsed && (
          <div className="bg-[#070d1e] rounded-xl p-2.5 border border-slate-800/80 text-[11px] shadow-inner relative overflow-hidden">
            <div className="absolute top-0 right-0 w-16 h-16 bg-emerald-500/5 rounded-full blur-md pointer-events-none" />
            <div className="flex items-center justify-between text-slate-400 mb-1">
              <span className="font-mono text-[10px] text-slate-400">TELEMETRY SYNC</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_6px_rgba(52,211,153,0.9)]" />
            </div>
            <div className="font-mono text-emerald-400 text-[11px] font-semibold flex items-center justify-between">
              <span>NOAA-20 / VIIRS</span>
              <span className="text-[10px] text-slate-400">99.8% READY</span>
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
