import React from 'react';
import {
  Compass,
  Radio,
  ArrowRight,
  Database,
  Cpu,
  MapPin,
  Telescope,
  Sparkles,
  Layers,
  ChevronRight,
  ExternalLink,
  Shield,
  Activity,
  Download,
  Eye,
  Cloud,
  Moon,
  Satellite
} from 'lucide-react';
import { ScreenType } from '../../types';

interface LandingPageProps {
  onNavigate: (screen: ScreenType) => void;
  onExploreSky?: () => void;
}

export const LandingPage: React.FC<LandingPageProps> = ({
  onNavigate,
  onExploreSky,
}) => {
  const handleExplore = () => {
    if (onExploreSky) {
      onExploreSky();
    } else {
      onNavigate('overview');
    }
  };

  return (
    <div className="min-h-screen bg-[#040816] text-slate-100 flex flex-col font-['Plus_Jakarta_Sans'] select-none cosmic-gradient-bg relative overflow-x-hidden">
      {/* Background Grid Accent */}
      <div className="absolute inset-0 cosmic-grid-pattern opacity-40 pointer-events-none" />

      {/* Top Public Navigation Bar */}
      <header className="h-20 border-b border-slate-800/80 bg-[#050917]/85 backdrop-blur-2xl sticky top-0 z-40 px-6 lg:px-12 flex items-center justify-between shadow-[0_4px_30px_rgba(0,0,0,0.6)]">
        <div className="flex items-center gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-sky-500 via-indigo-600 to-blue-700 p-0.5 shadow-[0_0_20px_rgba(14,165,233,0.4)] ring-1 ring-sky-400/40">
            <div className="w-full h-full bg-[#050917] rounded-[10px] flex items-center justify-center">
              <Radio className="w-5 h-5 text-sky-400 animate-pulse" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold text-xl tracking-tight text-white font-telemetry">
                AERO <span className="text-sky-400">CLEAR</span>
              </span>
              <span className="text-[10px] uppercase tracking-widest font-bold px-2 py-0.5 rounded-full bg-sky-500/20 text-sky-300 border border-sky-500/40 shadow-[0_0_8px_rgba(56,189,248,0.2)] font-mono">
                Orbital Tech
              </span>
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              Space Observation & Light-Pollution Intelligence Platform
            </p>
          </div>
        </div>

        {/* Center Nav Links */}
        <nav className="hidden md:flex items-center gap-8 text-xs font-semibold text-slate-300 uppercase tracking-wider">
          <button
            onClick={() => onNavigate('overview')}
            className="hover:text-sky-300 transition-colors cursor-pointer"
          >
            Dashboard
          </button>
          <button
            onClick={() => onNavigate('map')}
            className="hover:text-sky-300 transition-colors cursor-pointer"
          >
            Pollution Map
          </button>
          <button
            onClick={() => onNavigate('how-it-works')}
            className="hover:text-sky-300 transition-colors cursor-pointer"
          >
            Architecture
          </button>
          <button
            onClick={() => onNavigate('satellite-data')}
            className="hover:text-sky-300 transition-colors cursor-pointer"
          >
            Satellite Data
          </button>
          <button
            onClick={() => onNavigate('analytics')}
            className="hover:text-sky-300 transition-colors cursor-pointer"
          >
            Analytics
          </button>
        </nav>

        {/* Right CTA */}
        <div className="flex items-center gap-3">
          <a
            href="/aero-clear-project.zip"
            download="aero-clear-project.zip"
            className="hidden sm:flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 hover:border-sky-500/40 text-slate-200 hover:text-white text-xs font-semibold shadow-sm transition-all"
          >
            <Download className="w-3.5 h-3.5 text-sky-400" />
            <span>Download ZIP</span>
          </a>
          <button
            onClick={handleExplore}
            className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 hover:from-sky-500 hover:to-blue-500 text-white text-xs font-bold shadow-[0_0_20px_rgba(14,165,233,0.35)] transition-all hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <span>Explore the Sky</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative px-6 lg:px-12 pt-16 pb-24 overflow-hidden border-b border-slate-800/80">
        {/* Luminous Glow Orbs */}
        <div className="absolute top-1/4 left-1/3 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[400px] bg-gradient-to-tr from-sky-600/18 via-indigo-600/15 to-transparent blur-[140px] pointer-events-none" />
        <div className="absolute top-1/3 right-1/4 w-[500px] h-[300px] bg-gradient-to-bl from-blue-600/15 via-cyan-500/10 to-transparent blur-[120px] pointer-events-none" />

        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 items-center relative z-10">
          {/* Hero Left Content */}
          <div className="lg:col-span-6 space-y-6 text-left">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#0b1328]/90 border border-sky-500/40 text-sky-300 text-xs font-semibold shadow-[0_0_15px_rgba(14,165,233,0.15)] font-mono">
              <Sparkles className="w-3.5 h-3.5 text-sky-400 animate-pulse" />
              <span>Aerospace Remote-Sensing & Night Sky Intelligence</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-[1.12]">
              Cleaner Skies.{' '}
              <span className="shimmer-text">
                Brighter Discoveries.
              </span>
            </h1>

            <p className="text-base sm:text-lg text-slate-300 leading-relaxed max-w-xl">
              Aero Clear empowers astronomers and dark sky explorers to navigate artificial light pollution through calibrated satellite telemetry, atmospheric optics, and AI-assisted observation scoring.
            </p>

            {/* CTA Buttons */}
            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                id="hero-explore-btn"
                onClick={handleExplore}
                className="flex items-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-sky-600 via-indigo-600 to-blue-600 hover:from-sky-500 hover:via-indigo-500 hover:to-blue-500 text-white font-bold text-sm shadow-[0_0_25px_rgba(14,165,233,0.4)] transition-all hover:scale-105 active:scale-95 cursor-pointer border border-sky-400/40"
              >
                <span>Launch Mission Console</span>
                <Compass className="w-4 h-4" />
              </button>

              <button
                id="hero-how-it-works-btn"
                onClick={() => onNavigate('how-it-works')}
                className="flex items-center gap-2 px-6 py-3.5 rounded-xl bg-[#0b1328] border border-slate-700/80 text-slate-200 hover:text-white hover:bg-slate-800 hover:border-sky-500/50 font-semibold text-sm transition-all shadow-md cursor-pointer"
              >
                <span>Mission Architecture</span>
                <ChevronRight className="w-4 h-4 text-sky-400" />
              </button>

              <a
                href="/aero-clear-project.zip"
                download="aero-clear-project.zip"
                className="flex items-center gap-2 px-5 py-3.5 rounded-xl bg-sky-950/80 hover:bg-sky-900 border border-sky-500/40 text-sky-200 hover:text-white font-semibold text-sm transition-all shadow-md hover:scale-105 active:scale-95"
              >
                <Download className="w-4 h-4 text-sky-400" />
                <span>Export Source ZIP</span>
              </a>
            </div>

            {/* Quick Live Telemetry Ticker */}
            <div className="pt-4 flex flex-wrap items-center gap-6 text-xs text-slate-300 font-mono">
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-[0_0_8px_rgba(52,211,153,1)]" />
                <span>NOAA-20 / VIIRS Active</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-sky-400 shadow-[0_0_8px_rgba(56,189,248,1)]" />
                <span>Calibrated Bortle 1–9 Grid</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-indigo-400 shadow-[0_0_8px_rgba(99,102,241,1)]" />
                <span>Open-Meteo Real-Time Sync</span>
              </div>
            </div>
          </div>

          {/* Hero Right Visual: Planet Earth at Night with Satellites & Space Atmosphere */}
          <div className="lg:col-span-6 relative flex justify-center">
            <div className="relative w-full max-w-[500px] aspect-square rounded-3xl p-3 bg-gradient-to-b from-sky-500/20 via-blue-500/10 to-transparent border border-sky-500/30 shadow-[0_0_60px_rgba(14,165,233,0.15)] flex items-center justify-center overflow-hidden glass-panel">
              {/* Star backdrop SVG */}
              <svg className="absolute inset-0 w-full h-full opacity-70" xmlns="http://www.w3.org/2000/svg">
                <circle cx="45" cy="60" r="1.5" fill="#fff" opacity="0.8" />
                <circle cx="120" cy="180" r="1" fill="#c084fc" opacity="0.9" />
                <circle cx="340" cy="80" r="1.8" fill="#fff" opacity="0.7" />
                <circle cx="410" cy="220" r="1.2" fill="#60a5fa" opacity="0.85" />
                <circle cx="280" cy="390" r="1" fill="#fff" opacity="0.6" />
                <circle cx="90" cy="340" r="1.5" fill="#e879f9" opacity="0.8" />
                <circle cx="390" cy="380" r="1.2" fill="#fff" opacity="0.9" />
              </svg>

              {/* Glowing Earth Horizon & Night Lights simulation */}
              <div className="relative w-[360px] h-[360px] rounded-full bg-[#050811] shadow-[0_0_90px_rgba(59,130,246,0.45)] ring-1 ring-cyan-500/40 overflow-hidden flex items-center justify-center">
                {/* Night landmass and light pollution web */}
                <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-[#0A1224] to-[#04060D]" />
                
                {/* Heatmap ribbons mimicking Earth nocturnal lights */}
                <div className="absolute w-[260px] h-[190px] -top-8 -right-8 bg-gradient-to-br from-amber-500/60 via-orange-500/30 to-transparent blur-2xl rounded-full animate-pulse-subtle" />
                <div className="absolute w-[190px] h-[150px] top-24 left-4 bg-gradient-to-br from-yellow-500/50 via-red-500/20 to-transparent blur-xl rounded-full" />
                <div className="absolute w-[180px] h-[180px] bottom-4 right-12 bg-gradient-to-tr from-cyan-400/50 via-blue-600/30 to-transparent blur-2xl rounded-full" />

                {/* Atmospheric Ozone Glow Limb */}
                <div className="absolute inset-0 rounded-full border-[6px] border-cyan-400/40 blur-[2px]" />
                <div className="absolute inset-0 rounded-full border-[16px] border-blue-600/25 blur-[6px]" />

                {/* Satellite Orbit Rings */}
                <div className="absolute w-[420px] h-[170px] rounded-[100%] border border-sky-500/40 -rotate-[28deg] animate-[spin_24s_linear_infinite]" />
                <div className="absolute w-[380px] h-[230px] rounded-[100%] border border-indigo-500/30 rotate-[42deg]" />

                {/* Orbiting Satellite Indicator */}
                <div className="absolute top-12 right-16 flex items-center gap-1.5 bg-[#0F172A]/95 border border-sky-500/60 px-3 py-1 rounded-full text-[10px] text-sky-200 shadow-xl font-mono">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  <span>VIIRS (NOAA-20)</span>
                </div>

                {/* Center Mission Emblem */}
                <div className="relative text-center z-10 p-5">
                  <div className="text-xs uppercase tracking-widest text-cyan-300 font-mono font-bold">
                    Nocturnal Observation
                  </div>
                  <div className="text-2xl font-extrabold text-white tracking-tight mt-1 font-telemetry">
                    EARTH AT NIGHT
                  </div>
                  <div className="text-[11px] text-slate-300 mt-1 font-mono">
                    Multi-Spectral Radiance Mapping
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Live Observation Corridors Strip */}
      <section className="px-6 lg:px-12 py-8 bg-[#050917]/70 border-b border-slate-800/80">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4 text-xs">
          <div className="flex items-center gap-2 text-slate-400 font-mono uppercase tracking-wider text-[11px]">
            <Telescope className="w-4 h-4 text-sky-400" />
            <span>Featured Dark Sky Corridors:</span>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            {[
              { name: 'Siwa Oasis, Egypt', bortle: 'Class 2', quality: '9.4/10', status: 'Pristine' },
              { name: 'Wadi Rum, Jordan', bortle: 'Class 1', quality: '9.8/10', status: 'Sanctuary' },
              { name: 'Saint Catherine, Sinai', bortle: 'Class 2', quality: '9.1/10', status: 'High Alt' },
              { name: 'White Desert, Egypt', bortle: 'Class 1', quality: '9.7/10', status: 'Dark Sky' },
            ].map((site) => (
              <div 
                key={site.name}
                onClick={handleExplore}
                className="px-3 py-1.5 rounded-xl bg-[#091024] border border-slate-800 hover:border-sky-500/50 flex items-center gap-2 cursor-pointer transition-all hover:scale-105"
              >
                <span className="font-semibold text-white">{site.name}</span>
                <span className="text-sky-400 font-mono text-[10px]">{site.bortle}</span>
                <span className="px-1.5 py-0.2 rounded bg-emerald-950 text-emerald-300 font-mono text-[10px] border border-emerald-500/30">
                  {site.quality}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Two Thematic Sections: The Problem & How Aero Clear Helps */}
      <section className="px-6 lg:px-12 py-16 max-w-7xl mx-auto w-full">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* The Problem Card */}
          <div className="p-8 rounded-3xl bg-gradient-to-b from-[#0b1226] to-[#060b18] border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-red-500/50 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(239,68,68,0.15)]">
            <div className="relative z-10 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-red-950/60 border border-red-500/40 flex items-center justify-center text-red-400 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                <Activity className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight font-telemetry">
                THE CRISIS: ACCELERATING SKYGLOW
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                Artificial light at night (ALAN) washes out the stars, disrupts nocturnal wildlife, and limits humanity's window into the cosmos. Over 80% of the global population resides under heavily light-polluted skies, completely obscuring the Milky Way.
              </p>
              <div className="h-40 rounded-2xl overflow-hidden relative border border-slate-800/90 group-hover:border-red-500/40 transition-all">
                <img
                  src="https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80"
                  alt="City light pollution washing night sky"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />
                <span className="absolute bottom-3 left-3 text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-red-950/90 border border-red-500/50 text-red-200 shadow-md">
                  Urban Skyglow: Bortle Class 8–9
                </span>
              </div>
            </div>
          </div>

          {/* How Aero Clear Helps Card */}
          <div className="p-8 rounded-3xl bg-gradient-to-b from-[#0b1226] to-[#060b18] border border-slate-800/90 shadow-xl relative overflow-hidden group hover:border-sky-500/50 transition-all duration-300 hover:shadow-[0_10px_35px_rgba(14,165,233,0.15)]">
            <div className="relative z-10 space-y-4">
              <div className="w-12 h-12 rounded-2xl bg-sky-950/60 border border-sky-500/40 flex items-center justify-center text-sky-400 shadow-[0_0_15px_rgba(14,165,233,0.3)]">
                <Telescope className="w-6 h-6" />
              </div>
              <h2 className="text-2xl font-bold text-white tracking-tight font-telemetry">
                THE SOLUTION: PRECISION OBSERVATION
              </h2>
              <p className="text-sm text-slate-300 leading-relaxed">
                By fusing NASA Black Marble satellite radiance feeds with high-resolution Open-Meteo optical transparency forecasts, Aero Clear charts pristine dark sky corridors and guides observers to optimal discovery windows.
              </p>
              <div className="h-40 rounded-2xl overflow-hidden relative border border-slate-800/90 group-hover:border-sky-500/40 transition-all">
                <img
                  src="https://images.unsplash.com/photo-1506703719100-a0f3a48c0f86?auto=format&fit=crop&w=800&q=80"
                  alt="Pristine starry night sky"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/50 to-transparent" />
                <span className="absolute bottom-3 left-3 text-[11px] font-mono font-bold px-2.5 py-1 rounded-lg bg-sky-950/90 border border-sky-500/50 text-sky-200 shadow-md">
                  Dark-Sky Reserve: Bortle Class 1–2
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3-Step "How It Works" Section */}
      <section className="px-6 lg:px-12 py-16 border-t border-slate-800/80 bg-[#050917]/70">
        <div className="max-w-7xl mx-auto space-y-12 text-center">
          <div className="space-y-3">
            <div className="text-xs font-bold uppercase tracking-widest text-sky-400 font-mono">
              Scientific Pipeline
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight font-telemetry">
              END-TO-END TELEMETRY ARCHITECTURE
            </h2>
            <p className="text-sm text-slate-300 max-w-xl mx-auto">
              A high-precision pipeline translating raw Earth observation satellites into actionable astronomical decisions.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-left">
            {/* Step 1 */}
            <div className="p-8 rounded-3xl bg-[#070d1e] border border-slate-800/90 shadow-xl relative group hover:border-sky-500/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-2xl bg-sky-950/70 border border-sky-500/40 flex items-center justify-center text-sky-400 mb-6 group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(14,165,233,0.3)] transition-all">
                <Database className="w-7 h-7" />
              </div>
              <div className="text-xs font-mono font-bold text-sky-400 uppercase tracking-widest mb-1.5">
                Phase 01
              </div>
              <h3 className="text-xl font-bold text-white mb-2 font-telemetry">1. SATELLITE INGESTION</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Ingest calibrated multispectral feeds: VIIRS Day/Night Band radiance, MODIS cloud fractions, and digital surface elevation models to map nocturnal skyglow.
              </p>
            </div>

            {/* Step 2 */}
            <div className="p-8 rounded-3xl bg-[#070d1e] border border-slate-800/90 shadow-xl relative group hover:border-indigo-500/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-2xl bg-indigo-950/70 border border-indigo-500/40 flex items-center justify-center text-indigo-400 mb-6 group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(99,102,241,0.3)] transition-all">
                <Cpu className="w-7 h-7" />
              </div>
              <div className="text-xs font-mono font-bold text-indigo-400 uppercase tracking-widest mb-1.5">
                Phase 02
              </div>
              <h3 className="text-xl font-bold text-white mb-2 font-telemetry">2. OPTICAL SYNTHESIS</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Process real-time atmospheric optics: cloud ceiling, atmospheric visibility, relative humidity, and seeing conditions to calculate the Observation Quality Score.
              </p>
            </div>

            {/* Step 3 */}
            <div className="p-8 rounded-3xl bg-[#070d1e] border border-slate-800/90 shadow-xl relative group hover:border-emerald-500/50 transition-all duration-300 hover:-translate-y-1">
              <div className="w-14 h-14 rounded-2xl bg-emerald-950/70 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-6 group-hover:scale-110 group-hover:shadow-[0_0_20px_rgba(52,211,153,0.3)] transition-all">
                <MapPin className="w-7 h-7" />
              </div>
              <div className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest mb-1.5">
                Phase 03
              </div>
              <h3 className="text-xl font-bold text-white mb-2 font-telemetry">3. SANCTUARY DISCOVERY</h3>
              <p className="text-xs text-slate-300 leading-relaxed">
                Identify prime observation windows, pinpoint dark sky corridors with terrain shielding, and suggest optimal celestial deep-sky astrophotography targets.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Statistics Section with Elevated Telemetry Numbers */}
      <section className="px-6 lg:px-12 py-16 max-w-7xl mx-auto w-full">
        <div className="p-10 rounded-3xl bg-gradient-to-r from-[#070e24] via-[#091432] to-[#070e24] border border-sky-500/30 shadow-[0_0_40px_rgba(0,0,0,0.6)] relative overflow-hidden">
          <div className="absolute top-0 right-0 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none" />
          <div className="text-xs font-bold uppercase tracking-widest text-sky-400 mb-8 text-center font-mono">
            Platform Observability Matrix
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 text-center relative z-10">
            <div>
              <div className="text-4xl sm:text-5xl font-extrabold text-white font-telemetry tracking-tight">
                2.5M+
              </div>
              <div className="text-xs text-slate-300 mt-1.5 font-medium">
                km² Surface Area Modeled
              </div>
            </div>

            <div>
              <div className="text-4xl sm:text-5xl font-extrabold text-sky-400 font-telemetry tracking-tight">
                150+
              </div>
              <div className="text-xs text-slate-300 mt-1.5 font-medium">
                Certified Dark Sky Sites
              </div>
            </div>

            <div>
              <div className="text-4xl sm:text-5xl font-extrabold text-emerald-400 font-telemetry tracking-tight">
                85%
              </div>
              <div className="text-xs text-slate-300 mt-1.5 font-medium">
                Seeing Quality Improvement
              </div>
            </div>

            <div>
              <div className="text-4xl sm:text-5xl font-extrabold text-indigo-400 font-telemetry tracking-tight">
                5+
              </div>
              <div className="text-xs text-slate-300 mt-1.5 font-medium">
                Live Space Telemetry Feeds
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto border-t border-slate-800/80 bg-[#030612] px-6 lg:px-12 py-10 text-xs text-slate-400">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl bg-slate-900 border border-sky-500/40 flex items-center justify-center text-sky-300 shadow-[0_0_10px_rgba(56,189,248,0.3)]">
              <Radio className="w-4 h-4" />
            </div>
            <div>
              <span className="font-bold text-white text-sm font-telemetry tracking-wider">AERO CLEAR</span>
              <span className="text-[11px] text-slate-400 block font-mono">
                Space Observation & Light-Pollution Awareness
              </span>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-6">
            <button
              onClick={() => onNavigate('overview')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Dashboard
            </button>
            <button
              onClick={() => onNavigate('map')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Pollution Map
            </button>
            <button
              onClick={() => onNavigate('satellite-data')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Data Pipeline
            </button>
            <button
              onClick={() => onNavigate('how-it-works')}
              className="hover:text-white transition-colors cursor-pointer"
            >
              Documentation
            </button>
            <a
              href="/aero-clear-project.zip"
              download="aero-clear-project.zip"
              className="text-sky-400 hover:text-sky-300 font-semibold flex items-center gap-1 transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download ZIP</span>
            </a>
          </div>

          <div className="text-slate-400 text-center sm:text-right font-mono text-[11px]">
            © 2026 Aero Clear. Space Observation Hackathon Prototype.
          </div>
        </div>
      </footer>
    </div>
  );
};
